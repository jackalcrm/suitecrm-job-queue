<?php

$app_list_strings['moduleList']['job_queue'] = 'Jobs Queue';
$app_list_strings['moduleListSingular']['job_queue'] = 'Job Queue';
$app_list_strings['schedulers_status_dom'] = [
    'queued'  => 'Queued',
    'running' => 'Running',
    'done'    => 'Done'
];
$app_list_strings['schedulers_resolution_dom'] = [
    'queued'    => 'Queued',
    'partial'   => 'Partial',
    'success'   => 'Success',
    'running'   => 'Running',
    'failure'   => 'Failure',
    'cancelled' => 'Cancelled',
];
